package Pack;
public class Package_A
{
 public static void main(String args[]) 
 {
   System.out.println("Welcome in 'Pack' ");
 }
 public void msg()
   {
     System.out.println("From 'Pack' 'msg' method ");
   }
}


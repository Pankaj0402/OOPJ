public class IfElse 
{
    public static void main(String[] args) 
    {
        int number = -5;
        
        if (number > 0) 
        {
            System.out.println("The number is positive.");
        } 
        else 
         {
            System.out.println("The number is non-positive.");
        }
    }
}

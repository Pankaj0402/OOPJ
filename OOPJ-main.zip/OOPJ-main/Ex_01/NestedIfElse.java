public class NestedIfElse 
{
    public static void main(String[] args) 
    {
        int number = 0;
        
        if (number > 0) 
        {
            System.out.println("The number is positive.");
        } 
        else 
            {
             if (number < 0) 
                {
                  System.out.println("The number is negative.");
                } 
             else 
               {
                 System.out.println("The number is zero.");
               }
        }
    }
}
